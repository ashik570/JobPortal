@extends('layouts.front')
@section('content')
    
<div class="row">
    <div class="col-md-12 text-center">
        <img src="{{URL::to('/')}}/public/img/404.png" alt="404 - Not Found" title="404 - Not Found">
    </div>
</div>
   


@stop