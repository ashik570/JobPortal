@include('website.layouts.header')


<section  id="productDetails" class="product-details">
    <div class="container" style="padding-bottom: 30px;">
        <div class="row">

            <div class="col-md-3">

                <?php
                $productImageArr = json_decode($productInfo->product_image, true);
                ?>
                <div id="img-container">
                    <img class="add-main-image" src="{{URL::to('/')}}/public/uploads/website/product/{{ !empty(end($productImageArr)) ? end($productImageArr) : 'demo.jpg'  }}"  alt="">
                </div>
              
                <ul class="piclist">
                    @foreach($productImageArr as $productName)
                    <li><img src="{{URL::to('/')}}/public/uploads/website/product/{{$productName}}" alt=""></li>
                    @endforeach
                </ul>
            </div>


            <div class="col-md-9 details-div">

                <div class="product-details-info">
                    {{$productInfo->product_info}}
                    <br/>
                </div>
                <div class="regular-price">
                    <p>@lang('english.REGULAR_PRICE') {{$productInfo->price}}  @lang('english.TK')</p>

                    <p>@lang('english.SPECIAL_PRICE') {{$productInfo->special_price}}  @lang('english.TK')</p>

                </div>
                <div class="product-details-description">
                    {!!$productInfo->description!!}
                </div>
            </div>
        </div>

    </div>
</section>


<section  id="productCategories" class="product-details-categories">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4 class="section-heading related-hedding first-word">
                    @lang('english.RELATED_PRODUCTS')
                </h4>
            </div>
        </div>
        <div class="row equal">

            @if(!$productArr->isEmpty())
            @foreach($productArr as $product)
            <div class="col-md-2">
                <div class="item">
                    <a href="{{URL::to('/').'/product-details/'}}{{$product->id}}">
                        <div class="card product-details-block">
                            <div class="card-heading text-center bg-none">
                                <div class="product-image">
                                    <?php
                                    $productImageArr = json_decode($product->product_image, true);
                                    ?>
                                    <img width="100%" src="{{URL::to('/')}}/public/uploads/website/product/{{ !empty(end($productImageArr)) ? end($productImageArr) : 'demo.jpg'  }}" alt = "D-Care"/>
                                </div>

                            </div>
                            <div class="card-body">

                                <div class="text-center product-details-name">
                                    {{ $product->name??'' }}
                                </div>
                                <div class="text-center product-details-content">
                                    {!! $product->product_info??'' !!}
                                </div>
                                <div class="text-center product-details-price-dcare">
                                    @if(!empty($product->check_special_price))
                                    <del> @lang('english.TK').{!! $product->price??'' !!}</del>
                                    @lang('english.TK').{!! $product->special_price??'' !!}
                                    @else
                                    @lang('english.TK').{!! $product->price??'' !!}
                                    @endif
                                </div>

                            </div>
                        </div>
                    </a>    
                </div>
            </div>
            @endforeach
            @endif
        </div>
</section>

@include('website.layouts.footer')
<script src="{{asset('public/js/js-image-zoom.js')}}" type="text/javascript"></script>
<script type="text/javascript">
    $(function () {


        $('.piclist li').on('click', function (event) {
            var $pic = $(this).find('img');
            $('.add-main-image').attr('src', $pic.attr('src'));
            $(".js-image-zoom__zoomed-image").css("background-image", "url(" + $pic.attr('src') + ")");
        });
    });

    var options1 = {
        width: 400,
        zoomWidth: 500,
        offset: {vertical: 0, horizontal: 10}
    };

    // If the width and height of the image are not known or to adjust the image to the container of it
    var options2 = {};
    new ImageZoom(document.getElementById("img-container"), options2);

</script>