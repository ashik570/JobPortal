<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>{{trans('english.CSTI_FULL')}} </title>
       <link href="{{asset('public/assets/global/plugins/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
       <link href="{{asset('public/assets/global/css/components.min.css')}}" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <h2 class="font-red text-center">{{trans('english.JAVASCRIPT_ENABLE_ERROR')}} </h2>
    </body>
</html>

