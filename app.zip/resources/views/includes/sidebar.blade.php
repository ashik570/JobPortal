<?php
$currentControllerFunction = Route::currentRouteAction();
$currentCont = preg_match('/([a-z]*)@/i', request()->route()->getActionName(), $currentControllerFunction);
$currentControllerName = Request::segment(1);
// dd($currentControllerName);
$currentFullRouteName = Route::getFacadeRoot()->current()->uri();
$action = Route::currentRouteAction();
?>
<div class="page-sidebar-wrapper">
    <!-- BEGIN SIDEBAR -->
    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
    <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
    <div class="page-sidebar navbar-collapse collapse">
        <!-- BEGIN SIDEBAR MENU -->
        <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
        <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
        <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
        <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
        <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
        <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
        <ul class="page-sidebar-menu  page-header-fixed" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
            <!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
            <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
            <li class="sidebar-toggler-wrapper hide">
                <div class="sidebar-toggler">
                    <span></span>
                </div>
            </li>
            <!-- END SIDEBAR TOGGLER BUTTON -->

            <li class="heading">
                <h3 class="uppercase">Features</h3>
            </li>
            @if(!empty(Auth::user()->password_changed))

            @if(!empty(Session::get('program_id')))
            <li class="nav-item <?php echo (in_array($currentControllerName, array('dashboard', 'library', 'message', 'eresources'))) ? 'start active open' : ''; ?>">
                <a href="{{URL::to('dashboard')}}"  class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">{{ trans('english.DASHBOARD') }}</span>

                </a>
            </li>

            @if(Auth::user()->group_id <= '2' || Auth::user()->group_id == '6')
            <li class="nav-item <?php echo (in_array($currentControllerName, array('userGroup', 'users', 'rank', 'appointment', 'branch'))) ? 'start active open' : ''; ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="icon-users"></i>
                    <span class="title">{{ trans('english.USER_MANAGEMENT') }}</span>

                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item <?php echo ($currentControllerName == 'userGroup') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('userGroup')}}" class="nav-link ">
                            <span class="title">{{ trans('english.USER_GROUP') }}</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'rank') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('rank')}}" class="nav-link ">
                            <span class="title">{{ trans('english.RANK_MANAGEMENT') }}</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'appointment') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('appointment')}}" class="nav-link ">
                            <span class="title">{{ trans('english.APPOINTMENT_MANAGEMENT') }}</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'branch') ? 'start active open' : ''; ?> ">
                        <a href="{{URL::to('branch')}}" class="nav-link ">
                            <span class="title">{{ trans('english.BRANCH_MANAGEMENT') }}</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'users') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('users')}}" class="nav-link ">
                            <span class="title">{{ trans('english.USER_MANAGEMENT') }}</span>
                        </a>
                    </li>
                </ul>
            </li>

            <!--<li class="nav-item <?php echo (in_array($currentControllerName, array('configuration', 'instrForEpe', 'signatory', 'scrollmessage'))) ? 'start active open' : ''; ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="icon-settings"></i>
                    <span class="title">{{ trans('english.SETTING') }}</span>

                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                   
                </ul>
            </li>-->

            @endif

            @endif

            @if(in_array(Auth::user()->group_id, [1]))

            <li class="nav-item <?php
            echo (in_array($currentControllerName, array('product', 'qualityFactor'
                , 'statistics', 'certifications', 'services', 'sisterConcerns'
                , 'faculty', 'downloads', 'contact-info', 'ourService'
                , 'support', 'follow-us', 'content', 'coas-trophy'
                , 'torchbearer', 'programFeatures', 'programGallery', 'publication'
                , 'catpublication', 'publication', 'affiliations', 'ourPrograms'
                , 'ourSpecialty', 'businessSegments', 'slider', 'menu', 'whoWeAre'
                , 'messageFromOC', 'newsAndEvents', 'gAlbum', 'gallery', 'majorCategories'
                , 'productCategory', 'product', 'publication','contact-info','welcomeDcare'))) ? 'start active open' : '';
            ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="icon-check"></i>
                    <span class="title">@lang('english.WEBSITE')</span>

                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item <?php echo ($currentControllerName == 'menu') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('menu')}}" class="nav-link ">
                            <span class="title">@lang('english.MAIN_MENU')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'content') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('content')}}" class="nav-link ">
                            <span class="title">@lang('english.CONTENT')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'slider') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('slider')}}" class="nav-link ">
                            <span class="title">@lang('english.SLIDER')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'whoWeAre') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('whoWeAre')}}" class="nav-link ">
                            <span class="title">@lang('english.WHO_WE_ARE')</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item <?php echo ($currentControllerName == 'messageFromOC') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('messageFromOC')}}" class="nav-link ">
                            <span class="title">@lang('english.MESSAGE_FROM_OC')</span>
                        </a>
                    </li> -->
                    <li class="nav-item <?php echo ($currentControllerName == 'businessSegments') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('businessSegments')}}" class="nav-link ">
                            <span class="title">@lang('english.BUSINESS_SEGMENTS')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'ourSpecialty') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('ourSpecialty')}}" class="nav-link ">
                            <span class="title">@lang('english.OUR_SPECIALITY')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'majorCategories') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('majorCategories')}}" class="nav-link ">
                            <span class="title">@lang('english.MAJOR_CATEGORIES')</span>
                        </a>
                    </li>



                    <li class="nav-item <?php echo ($currentControllerName == 'affiliations') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('affiliations')}}" class="nav-link ">
                            <span class="title">@lang('english.AFFILIATIONS_MEMBERSHIPS')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'newsAndEvents') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('newsAndEvents')}}" class="nav-link ">
                            <span class="title">@lang('english.LATEST_NEWS_EVENTS')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'statistics') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('statistics')}}" class="nav-link ">
                            <span class="title">@lang('english.STATISTICS')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'publication') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('publication')}}" class="nav-link ">
                            <span class="title">@lang('english.PUBLICATION')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'ourPrograms') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('ourPrograms')}}" class="nav-link ">
                            <span class="title">@lang('english.OUR_PROGRAM')</span>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($currentControllerName == 'contact-info') ? 'start active open' : ''; ?>">
                        <a href="{{URL::to('contact-info')}}" class="nav-link ">
                            <span class="title">@lang('english.CONTACT')</span>
                        </a>
                    </li>

                    <li class="nav-item <?php echo (in_array($currentControllerName, array('gAlbum', 'gallery'))) ? 'start active open' : ''; ?>">
                        <a href="javascript:;" class="nav-link nav-toggle">
                            <i class="icon-check"></i>
                            <span class="title">@lang('english.GALLERY')</span>

                            <span class="arrow open"></span>
                        </a>
                        <ul class="sub-menu" style="margin-top:5px;">
                            <li class="nav-item <?php echo ($currentControllerName == 'gAlbum') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('gAlbum')}}" class="nav-link ">
                                    <span class="title">@lang('english.ALBUM')</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo ($currentControllerName == 'gallery') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('gallery')}}" class="nav-link ">
                                    <span class="title">@lang('english.GALLERY_IMAGE')</span>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <!--<li class="nav-item <?php echo (in_array($currentControllerName, array('ourService', 'contact-info', 'support'))) ? 'start active open' : ''; ?>">
                        <a href="javascript:;" class="nav-link nav-toggle">
                            <i class="icon-check"></i>
                            <span class="title">@lang('english.FOOTER')</span>

                            <span class="arrow open"></span>
                        </a>
                        <ul class="sub-menu" style="margin-top:5px;">
                            <li class="nav-item <?php echo ($currentControllerName == 'contact-info') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('contact-info')}}" class="nav-link ">
                                    <span class="title">@lang('english.CONTACT')</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo ($currentControllerName == 'ourService') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('ourService')}}" class="nav-link ">
                                    <span class="title">@lang('english.OUR_SERVICES')</span>
                                </a>
                            </li>
                            <li class="nav-item <?php echo ($currentControllerName == 'support') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('support')}}" class="nav-link ">
                                    <span class="title">@lang('english.SUPPORT')</span>
                                </a>
                            </li>
                        </ul>
                    </li>-->
                    <li class="nav-item <?php echo (in_array($currentControllerName, array('productCategory', 'product','welcomeDcare'))) ? 'start active open' : ''; ?>">
                        <a href="javascript:;" class="nav-link nav-toggle">
                            <i class="icon-eye"></i>
                            <span class="title">@lang('english.D_CARE')</span>

                            <span class="arrow open"></span>
                        </a>
                        <ul class="sub-menu" style="margin-top:5px;">
                             <li class="nav-item <?php echo ($currentControllerName == 'welcomeDcare') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('welcomeDcare')}}" class="nav-link ">
                                    <span class="title">@lang('english.WELCOME')</span>
                                </a>
                            </li>
                            <li class="nav-item <?php echo ($currentControllerName == 'productCategory') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('productCategory')}}" class="nav-link ">
                                    <span class="title">@lang('english.PRODUCT_CATEGORY')</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo ($currentControllerName == 'product') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('product')}}" class="nav-link ">
                                    <span class="title">@lang('english.PRODUCT')</span>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <!--<li class="nav-item <?php echo (in_array($currentControllerName, array('ourService', 'contact-info', 'support'))) ? 'start active open' : ''; ?>">
                        <a href="javascript:;" class="nav-link nav-toggle">
                            <i class="icon-check"></i>
                            <span class="title">@lang('english.FOOTER')</span>

                            <span class="arrow open"></span>
                        </a>
                        <ul class="sub-menu" style="margin-top:5px;">
                            <li class="nav-item <?php echo ($currentControllerName == 'contact-info') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('contact-info')}}" class="nav-link ">
                                    <span class="title">@lang('english.CONTACT')</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo ($currentControllerName == 'ourService') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('ourService')}}" class="nav-link ">
                                    <span class="title">@lang('english.OUR_SERVICES')</span>
                                </a>
                            </li>
                            <li class="nav-item <?php echo ($currentControllerName == 'support') ? 'start active open' : ''; ?>">
                                <a href="{{URL::to('support')}}" class="nav-link ">
                                    <span class="title">@lang('english.SUPPORT')</span>
                                </a>
                            </li>
                        </ul>
                    </li>-->
                </ul>
            </li>
            @endif
            @endif
        </ul>
        <!-- END SIDEBAR MENU -->
        <!-- END SIDEBAR MENU -->
    </div>
    <!-- END SIDEBAR -->
</div>
