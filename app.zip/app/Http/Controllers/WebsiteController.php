<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use Helper;
use Validator;
use DB;
use Redirect;
use URL;
use DateTime;
use App\Message;
use App\Configuration;
use App\Gallery;
use App\Slide;
use App\WhoWeAre;
use App\MessageFromOC;
use App\MissionAndVision;
use App\OurSpecialty;
use App\OurPrograms;
use App\ProgramFeature;
use App\ProgramGallery;
use App\Affiliations;
use App\NewsAndEvents;
use App\Publication;
use App\PublicationCategory;
use App\GAlbum;
use App\Content;
use App\Rank;
use App\Branch;
use App\ContactInfo;
use App\WelcomeDcare;
use App\Product;

class WebsiteController extends Controller {

    public function whoWeAre(Request $reques) {
        $targetArr = WhoWeAre::select('title', 'content')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }

    public function messageFromOC(Request $reques) {
        $targetArr = MessageFromOC::select('title', 'content', 'oc_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }

    public function missionAndVision(Request $reques) {
        $targetArr = MissionAndVision::select('title', 'content', 'featured_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }

    public function ourSpecialty(Request $request, $slug) {
        $targetArr = OurSpecialty::where('slug', $slug)->select('title', 'content', 'featured_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }

    public function affiliationDetails(Request $request, $slug) {
        $targetArr = Affiliations::where('slug', $slug)->select('title', 'content', 'featured_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }

    public function contentDetail(Request $request, $id) {
        $target = Content::find($id);
        return view('website.frontend.template.contentDetail', compact('target'));
    }

    public function contactUs(Request $request) {
        $targetInfo = ContactInfo::first();
        return view('website.frontend.template.contactUs', compact('targetInfo'));
    }

    public function galleryAlbum(Request $request) {
        $targetArr = GAlbum::select('id', 'slug', 'title', 'cover_photo', 'content')->get();
        return view('website.frontend.template.galleryAlbum', compact('targetArr'));
    }

    public function galleryPhotos(Request $request, $slug) {
        $albumInfo = GAlbum::where('slug', $slug)->select('id', 'title')->first();
        $targetArr = Gallery::orderBy('order', 'ASC')
                        ->where('album_id', $albumInfo->id)
                        ->where('status_id', '1')
                        ->select('caption', 'thumb', 'photo')->get();
        return view('website.frontend.template.galleryPhotos', compact('targetArr', 'albumInfo'));
    }

    public function newsAndEvents(Request $request) {

        $targetArr = NewsAndEvents::orderBY('order', 'ASC')->where('status_id', 1)->paginate(3);
        return view('website.frontend.template.posts', compact('targetArr'));
    }

    public function postDetail(Request $request, $slug) {
        $postDetail = NewsAndEvents::where('slug', $slug)->first();
        $otherPost = NewsAndEvents::where('slug', '!=', $slug)->get();
        return view('website.frontend.template.postDetail', compact('postDetail', 'otherPost'));
    }

    public function publication(Request $request) {

        $targetArr = Publication::get();
        return view('website.frontend.template.publication', compact('targetArr'));
    }

    public function concerns(Request $request) {

        $slider = ProgramGallery::orderBy('order', 'ASC')->get();
        $welcomeInfo = WelcomeDcare::first();
        $productArr = Product::join('product_category', 'product_category.id', '=', 'product.product_category_id')
                        ->join('product_image', 'product_image.product_id', '=', 'product.id')
                        ->select('product.*', 'product_category.name as product_category', 'product_image.image as product_image')->get();

        return view('website.frontend.template.concerns', compact('slider', 'welcomeInfo', 'productArr'));
    }

    public function productDetails(Request $request, $id) {

        $productInfo = Product::join('product_category', 'product_category.id', '=', 'product.product_category_id')
                        ->join('product_image', 'product_image.product_id', '=', 'product.id')
                        ->select('product.*', 'product_category.name as product_category', 'product_image.image as product_image')
                        ->where('product.id', $id)->first();
        $productArr = Product::join('product_category', 'product_category.id', '=', 'product.product_category_id')
                        ->join('product_image', 'product_image.product_id', '=', 'product.id')
                        ->select('product.*', 'product_category.name as product_category', 'product_image.image as product_image')->get();

        return view('website.frontend.template.productDetails', compact('productInfo','productArr'));
    }

}
