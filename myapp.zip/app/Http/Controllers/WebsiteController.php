<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use Helper;
use Validator;
use DB;
use Redirect;
use URL;
use DateTime;
use App\Message;
use App\Configuration;
use App\Gallery;
use App\Slide;
use App\WhoWeAre;
use App\MessageFromOC;
use App\MissionAndVision;
use App\OurSpecialty;
use App\OurPrograms;
use App\ProgramFeature;
use App\ProgramGallery;
use App\Affiliations;
use App\NewsAndEvents;
use App\Publication;
use App\PublicationCategory;
use App\GAlbum;
use App\Content;
use App\Rank;
use App\Branch;

class WebsiteController extends Controller {

    public function whoWeAre(Request $reques){
        $targetArr = WhoWeAre::select('title','content')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }
    
    public function messageFromOC(Request $reques){
        $targetArr = MessageFromOC::select('title','content','oc_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }
    
    public function missionAndVision(Request $reques){
        $targetArr = MissionAndVision::select('title','content','featured_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }
    
    public function ourSpecialty(Request $request, $slug){
        $targetArr = OurSpecialty::where('slug', $slug)->select('title','content','featured_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }
    
    public function affiliationDetails(Request $request, $slug){
        $targetArr = Affiliations::where('slug', $slug)->select('title','content','featured_image')->first();
        return view('website.frontend.template.aboutUs', compact('targetArr'));
    }
    
    
    public function contentDetail(Request $request, $id){
        $target = Content::find($id);
        return view('website.frontend.template.contentDetail', compact('target'));
    }
    
    public function contactUs(Request $request){
        return view('website.frontend.template.contactUs');
    }
    

    
    public function galleryAlbum(Request $request){
        $targetArr = GAlbum::select('id', 'slug', 'title', 'cover_photo', 'content')->get();
        return view('website.frontend.template.galleryAlbum', compact('targetArr'));
    }
    
    public function galleryPhotos(Request $request, $slug){
        $albumInfo = GAlbum::where('slug', $slug)->select('id', 'title')->first();
        $targetArr = Gallery::orderBy('order', 'ASC')
                ->where('album_id', $albumInfo->id)
                ->where('status_id', '1')
                ->select('caption', 'thumb', 'photo')->get();
        return view('website.frontend.template.galleryPhotos', compact('targetArr','albumInfo'));
    }

    public function newsAndEvents(Request $request){
        
        $targetArr = NewsAndEvents::orderBY('order', 'ASC')->where('status_id', 1)->paginate(3);
        return view('website.frontend.template.posts',  compact('targetArr'));
        
    }
    public function postDetail(Request $request, $slug){
        $postDetail = NewsAndEvents::where('slug', $slug)->first();
        $otherPost =  NewsAndEvents::where('slug', '!=', $slug)->get();
        return view('website.frontend.template.postDetail',  compact('postDetail','otherPost'));
        
    }
    public function publication(Request $request, $id){
        $publicationInfo = PublicationCategory::select('name')->where('id',$id)->first();
        $targetArr = Publication::where('publication_category_id', $id)->get();
        return view('website.frontend.template.publication',  compact('targetArr','publicationInfo'));
    }
    
    
    
    
}
