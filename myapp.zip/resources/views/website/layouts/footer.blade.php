<footer class="footer">
    <!--<div class="cta cta-horizontal cta-horizontal-box bg-dark bg-image" >
        <div class="container">
            <div class="row align-items-center">
                
                <div class="col-md-2">
                    <h5 class="footer-title">
                        @lang('english.OUR_SERVICES')
                    </h5>
                    <div class="footer-content">
                        <div class="utilities">
                            <ul class="">
                                @if(!$utilitiesArr->isEmpty())
                                @foreach($utilitiesArr as $utility)
                                <li class="utility-item"><a href="{{ $utility->url }}">{!! $utility->title !!}</a></li>
                                @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <h5 class="footer-title">
                        @lang('english.SUPPORT')
                    </h5>
                    <div class="footer-content">
                        <div class="utilities">
                            <ul class="">
                                @if(!$importantLinksArr->isEmpty())
                                @foreach($importantLinksArr as $importantLink)
                                <li class="utility-item"><a href="{{ $importantLink->url }}">{!! $importantLink->title !!}</a></li>
                                @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <h5 class="footer-title">
                        @lang('english.CONTACT')
                    </h5>
                    <div class="footer-content">
                        <div class="contact-us">
                            <ul class="">
                                @if(!$contactInfoArr->isEmpty())
                                @foreach($contactInfoArr as $contactInfo)
                                <li class="contact-info-item"> {!! $contactInfo->title !!}</li>
                                @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
            
                        <div class="input-group">
                            <input type="email" class="form-control" id="email" placeholder="Email Address" autocomplete="off" aria-label="Email Adress" required>
                            <div class="input-group-append">
                                <button class="btn" id="submitBtn" type="button">@lang('english.SUBSCRIBE')</button>
                            </div>
    <!-- .End .input-group-append -->
                        <!--</div><!-- .End .input-group -->
                     <!--<span class="text-danger" id="error"></span>
                     <span class="text-success" id="success"></span>
                </div><!-- End .container-fluid -->
           <!-- </div><!-- End .cta -->
       <!-- </div><!-- End .cta -->
    <!--</div>-->


    <div class="footer-bottom">
        <div class="container-fluid">
            <p class="footer-copyright">@lang('english.COPYRIGHT')</p><!-- End .footer-copyright -->
            <div class="social-icons social-icons-color">
          
                <a href="#" class="social-icon social-facebook" title="Facebook" target="_blank"><i class="icon-facebook-f"></i></a>
                <a href="#" class="social-icon social-twitter" title="Twitter" target="_blank"><i class="icon-twitter"></i></a>
                <a href="#" class="social-icon social-instagram" title="Instagram" target="_blank"><i class="icon-instagram"></i></a>
                <a href="#" class="social-icon social-youtube" title="Youtube" target="_blank"><i class="icon-youtube"></i></a>
                <a href="#" class="social-icon social-pinterest" title="Pinterest" target="_blank"><i class="icon-pinterest"></i></a>
            </div><!-- End .soial-icons -->
        </div><!-- End .container-fluid -->
    </div><!-- End .footer-bottom -->
</footer><!-- End .footer -->
</div><!-- End .page-wrapper -->
<button id="scroll-top" title="Back to Top"><i class="icon-arrow-up"></i></button>

<!-- Mobile Menu -->
<div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

<div class="mobile-menu-container">
    <div class="mobile-menu-wrapper">
        <span class="mobile-menu-close"><i class="icon-close"></i></span>

        <form action="#" method="get" class="mobile-search">
            <label for="mobile-search" class="sr-only">Search</label>
            <input type="search" class="form-control" name="mobile-search" id="mobile-search" placeholder="Search in..." required>
            <button class="btn btn-primary" type="submit"><i class="icon-search"></i></button>
        </form>

        <ul class="nav nav-pills-mobile" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="mobile-menu-link" data-toggle="tab" href="#mobile-menu-tab" role="tab" aria-controls="mobile-menu-tab" aria-selected="true">Menu</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="mobile-cats-link" data-toggle="tab" href="#mobile-cats-tab" role="tab" aria-controls="mobile-cats-tab" aria-selected="false">Categories</a>
            </li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="mobile-menu-tab" role="tabpanel" aria-labelledby="mobile-menu-link">
                <nav class="mobile-nav">
                    <ul class="mobile-menu">
                        <?php
                        $parentItem = 'parent-item ';
                        foreach ($globalparameterArr['menuArr'] as $menu):
                            $liClass = 'level1';
                            $aClass = '';
                            $caret = '';
                            $menuIcon = '';
                            if (array_key_exists('child', $menu)) {
                                if (sizeof($menu['child']) > 0) {
                                    //print_r($menu['child']);
                                    $liClass = 'dropdown';
                                    $aClass = 'dropdown-toggle';
                                    $caret = '<b class="caret"></b>';
                                }
                            }
                            $activeClass = (Request::url() == $menu['target_url']) ? 'active' : '';

                            if (!empty($menu['icon'])) {
                                $menuIcon = '<span class="menu-icon"><i class="' . $menu['icon'] . '"></i></span>';
                            }

                            echo "<li><a  href=" . $menu['target_url'] . ">" . $menu['title'] . "</a>";
                            if (array_key_exists('child', $menu)):
                                if (!empty($menu['child'])) {
                                    echo "<ul>";
                                    foreach ($menu['child'] as $child_menu):
                                        $activeClass = (Request::url() == $child_menu['target_url']) ? 'class="active-child" data-parent-id="' . $child_menu['parent_id'] . '"' : '';
                                        if ($child_menu['open_new_tab'] == 1) {
                                            echo "<li><a href='{$child_menu['target_url']}'  target='_blank'>{$child_menu['title']}</a>";
                                        } else {
                                            echo "<li><a href='{$child_menu['target_url']}' >{$child_menu['title']}</a>";
                                        }
                                        if (array_key_exists('child', $child_menu)):
                                            if (!empty($child_menu['child'])) {
                                                echo "<ul>";
                                                foreach ($child_menu['child'] as $child2_menu) :
                                                    echo "<li><a href='{$child2_menu['target_url']}'>{$child2_menu['title']}</a>";
                                                endforeach;
                                                echo "</ul>";
                                            }
                                        endif;
                                    endforeach;
                                    echo "</ul>";
                                }
                            endif;
                            echo "</li>";
                        endforeach;
                        ?>

                    </ul>
                </nav><!-- End .mobile-nav -->
            </div><!-- .End .tab-pane -->
            <div class="tab-pane fade" id="mobile-cats-tab" role="tabpanel" aria-labelledby="mobile-cats-link">
                <nav class="mobile-cats-nav">
                    <ul class="mobile-cats-menu">
                        <li><a class="mobile-cats-lead" href="#">Daily offers</a></li>

                    </ul><!-- End .mobile-cats-menu -->
                </nav><!-- End .mobile-cats-nav -->
            </div><!-- .End .tab-pane -->
        </div><!-- End .tab-content -->

        <div class="social-icons">
            <a href="#" class="social-icon" target="_blank" title="Facebook"><i class="icon-facebook-f"></i></a>
            <a href="#" class="social-icon" target="_blank" title="Twitter"><i class="icon-twitter"></i></a>
            <a href="#" class="social-icon" target="_blank" title="Instagram"><i class="icon-instagram"></i></a>
            <a href="#" class="social-icon" target="_blank" title="Youtube"><i class="icon-youtube"></i></a>
        </div><!-- End .social-icons -->
    </div><!-- End .mobile-menu-wrapper -->
</div><!-- End .mobile-menu-container -->

<!-- Plugins JS File -->
<script src="{{ asset('public/frontend/assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/jquery.hoverIntent.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/jquery.waypoints.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/superfish.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/bootstrap-input-spinner.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/jquery.plugin.min.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/jquery.countdown.min.js') }}"></script>
<!-- Main JS File -->
<!--------Album----------->
<script src="{{asset('public/css/gallery/js/album.js.download.js')}}" type="text/javascript"></script>
<script src="{{asset('public/js/owl.carousel.min.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/picturefill.min.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/lightgallery.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/lg-thumbnail.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/lg-video.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/lg-autoplay.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/lg-zoom.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/lg-hash.js')}}"  type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/lg-pager.js')}}" type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/gallery/jquery.mousewheel.min.js')}}" type="text/javascript"></script>
<script src="{{asset('public/css/gallery/js/nivo-lightbox.js')}}" type="text/javascript"></script>
<!--gallery-->
<script src="{{ asset('public/frontend/assets/js/main.js') }}"></script>
<script src="{{ asset('public/frontend/assets/js/dysin.js') }}"></script>
<script type="text/javascript">

    $(document).on('click', '#submitBtn', function (e) {
        var email = $('#email').val();
        $.ajax({
            url: "{{URL::to('userSubcription')}}",
            type: 'POST',
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                email: email
            },
            beforeSend: function () {
                $('#display').html('');
            },
            success: function (res) {
                $('#success').text('@lang("english.SUCCESSFULLY_SUBSCRIBED")');
                 $('#error').text('');
            },
            error: function (jqXhr, ajaxOptions, thrownError) {
                if (jqXhr.status == 400) {
                } else if (jqXhr.status == 401) {
                  $('#error').text(jqXhr.responseJSON.message);
                  $('#success').text(' ');
                } else {
                    $('#error').text('Error');
                     $('#success').text(' ');
                }
 
            }
        });
    });
    
    $(document).ready(function(){
    $(".active-child").closest("li.parent-item").addClass('active');
    });
    $(document).ready(function () {
        $('.lightgallery').lightGallery();
    });
</script>
@yield('page-script')
</body>

</html>
