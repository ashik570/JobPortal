<?php

//Route::get('/', 'HomeController@index')->name('/');
Route::get('/', 'HomeController@home')->name('home');
Route::get('about_us', 'HomeController@aboutUs');
Route::get('content-details/{id}', 'WebsiteController@contentDetail');

Route::get('who-we-are', 'WebsiteController@whoWeAre');
Route::get('mission-and-vision', 'WebsiteController@missionAndVision');
Route::get('our-specialty/{slug}', 'WebsiteController@ourSpecialty');
Route::get('affiliation-details/{slug}', 'WebsiteController@affiliationDetails');

Route::get('contact-us', 'WebsiteController@contactUs');
Route::get('gallery-album', 'WebsiteController@galleryAlbum');
Route::get('galleryweb/{slug}', 'WebsiteController@galleryPhotos');
Route::get('news-and-events', 'WebsiteController@newsAndEvents');
Route::get('news-and-events/{slug}', 'WebsiteController@postDetail');
Route::get('publications/{id}', 'WebsiteController@publication');
//shakiur

Route::get('photo_gallery', 'HomeController@gallery');
Route::get('javacriptEnable', 'HomeController@javacriptEnable');

Route::post('forgotPassword', 'ForgotPasswordController@forgotPassword');
Route::get('recoverPassword/{id}', 'ForgotPasswordController@recoverPassword');
Route::post('resetPassword', 'ForgotPasswordController@resetPassword');

Route::get('mail', array('uses' => 'MailController@index'));
Auth::routes();





Route::group(['middleware' => 'auth'], function () {

//    Route::get('manual/', 'ManualController@index')->name('manual');
//    Route::get('manual/download/{id}', 'ManualController@manualDownload');

    Route::post('setRecordPerPage', 'UsersController@setRecordPerPage');

    Route::get('ajaxresponse/user-info', 'AjaxResponseController@getUserInfo');
    Route::get('ajaxresponse/relate-part-list', 'AjaxResponseController@getRelatePartList');
    Route::get('ajaxresponse/part-list', 'AjaxResponseController@getPartList');
    Route::post('ajaxresponse/show-subject', 'AjaxResponseController@postShowSubject');
    Route::post('ajaxresponse/create-children-informaion', 'AjaxResponseController@postCreateChildrenInformation');
    Route::post('ajaxresponse/create-family-information', 'AjaxResponseController@postCreateFamilyInformation');
    Route::post('ajaxresponse/create-civil-information', 'AjaxResponseController@postCreateCivilInformation');
    Route::post('ajaxresponse/create-honor-information', 'AjaxResponseController@postCreateHonorInformation');
    Route::post('ajaxresponse/create-punishment-information', 'AjaxResponseController@postCreatePunishmentInformation');
    Route::post('ajaxresponse/create-defence-information', 'AjaxResponseController@postCreateDefenceInformation');
    Route::post('ajaxresponse/create-course-attended-information', 'AjaxResponseController@postCreateCourseAttendedInformation');
    Route::post('ajaxresponse/create-unit-information', 'AjaxResponseController@postCreateUnitInformation');
    Route::post('ajaxresponse/create-medical-information', 'AjaxResponseController@postCreateMedicalInformation');
    Route::post('ajaxresponse/create-service-information', 'AjaxResponseController@postCreateServiceInformation');
    Route::get('ajaxresponse/edit-children', 'AjaxResponseController@getEditChildren');
    Route::get('ajaxresponse/edit-civil-education', 'AjaxResponseController@getEditCivilEducation');
    Route::get('ajaxresponse/edit-service-info', 'AjaxResponseController@getEditServiceInfo');
    Route::get('ajaxresponse/edit-award-info', 'AjaxResponseController@getEditAwardInfo');
    Route::get('ajaxresponse/edit-punishment-info', 'AjaxResponseController@getEditPunishmentInfo');
    Route::get('ajaxresponse/edit-defence-info', 'AjaxResponseController@getEditDefenceInfo');
    Route::get('ajaxresponse/edit-unit-info', 'AjaxResponseController@getEditUnitInfo');
    Route::get('ajaxresponse/edit-course-info', 'AjaxResponseController@getEditCourseInfo');
    Route::get('ajaxresponse/edit-medical-info', 'AjaxResponseController@getEditMedicalInfo');
    Route::get('ajaxresponse/change-picture', 'AjaxResponseController@getChangePicture');
    Route::get('ajaxresponse/notice-details', 'AjaxResponseController@getNoticeDetails');
    Route::get('ajaxresponse/student-info', 'AjaxResponseController@getStudentInfo');
    Route::get('ajaxresponse/mock-info', 'AjaxResponseController@getMockInfo');
    Route::get('ajaxresponse/epe-info', 'AjaxResponseController@getEpeInfo');
    Route::get('ajaxresponse/irregular-epe-info', 'AjaxResponseController@getIrregularEpeInfo');
    Route::get('ajaxresponse/student-notice-details', 'AjaxResponseController@getStudentNoticeDetails');
    Route::get('ajaxresponse/student-details', 'AjaxResponseController@getStudentDetails');



    Route::get('dashboard', 'Admin\DashboardController@index');

    Route::get('forcePasswordChange', 'Admin\DashboardController@forcePasswordChange');
    Route::post('forcePasswordChange', 'Admin\DashboardController@updatePassword');

    Route::get('dashboard/admin', 'Admin\DashboardController@admin');
    Route::post('dashboard/change_picture', 'Admin\DashboardController@changePicture');




    // Users Management Access Admin/OC All Program. Check this Controller Construct Method
    // Only cpself and editProfile Method Access All Program all User
    // :::::::: Start User Route ::::::::::::::
    Route::post('users/cpself/', 'UsersController@cpself');
    Route::get('users/cpself/', function() {
        return View::make('users/change_password_self');
    });
    Route::get('users/profile/', function () {
        return View::make('users/user_profile');
    });
    Route::post('users/editProfile/', 'UsersController@editProfile');
    Route::resource('users', 'UsersController', ['except' => ['show']]);
    Route::get('users/activate/{id}/{param?}', 'UsersController@active');
    Route::post('users/pup/', 'UsersController@pup');
    Route::post('users/filter/', 'UsersController@filter');
    Route::get('users/cp/{id}/{param?}', 'UsersController@change_pass');
    // :::::::: End User Route ::::::::::::::
    // :::::::: Start Notice Route ::::::::::::::
    // Notice  Access Admin/OC/CI All Program. Check this Controller Construct Method
    // Only index Method Access All Program all User
    Route::resource('notice', 'NoticeController', ['except' => ['show']]);
    Route::get('notice/download/{id}', 'NoticeController@getDownload');
    Route::post('notice/filter', 'NoticeController@filter');
    // :::::::: End Notice Route ::::::::::::::

    Route::get('message', 'MessageController@index');
    //// this Controller Access all user and All program
});





// <--- End of only ISSP,JCSC (All) program Admin,OC,CI,Student access --->
Route::group(['middleware' => ['auth']], function () {

  Route::post('branch/filter', 'BranchController@filter');
  Route::resource('userGroup', 'UserGroupController');

  Route::resource('rank', 'RankController');
  Route::resource('appointment', 'AppointmentController');
  Route::resource('branch', 'BranchController');

    // website
    Route::resource('slider', 'SliderController');

    Route::resource('menu', 'MenuController');
    Route::post('menu/getOrder/', 'MenuController@getOrder');
    Route::post('menu/filter/', 'MenuController@filter');
    Route::post('menu/getTypeWiseField/', 'MenuController@getTypeWiseField');

    // content
    Route::resource('content', 'ContentController');

    //HOME : Who We Are
    Route::get('whoWeAre', 'WhoWeAreController@index');
    Route::Post('whoWeAre', 'WhoWeAreController@update')->name('whoWeAre.update');


    Route::get('businessSegments', 'BusinessSegmentsController@index');
    Route::Post('businessSegments', 'BusinessSegmentsController@update')->name('businessSegments.update');

    //HOME : At A Glance
    Route::resource('ourSpecialty', 'OurSpecialtyController');

    //HOME : Our Affiliations
    Route::resource('affiliations', 'AffiliationsController');

    // Services
    Route::resource('services', 'ServicesController');

    // Sister Concerns
    Route::resource('sisterConcerns', 'SisterConcernsController');

    // Certifications
    Route::resource('certifications', 'CertificationsController');

    // Statistics
    Route::resource('statistics', 'StatisticsController');

    // Quality Factor
    Route::resource('qualityFactor', 'QualityFactorController');

    // Product
    Route::resource('product', 'ProductController');

    // News And Events
    Route::resource('newsAndEvents', 'NewsAndEventsController');

    //Publication
    Route::post('publication/filter/', 'PublicationController@filter');
    Route::post('/publication/getOrder/', 'PublicationController@getOrder');
    Route::resource('publication', 'PublicationController');

    Route::post('catpublication/filter/', 'PublicationCategoryController@filter');
    Route::resource('catpublication', 'PublicationCategoryController');

    // Gallery
    Route::resource('gAlbum', 'GAlbumController');
    Route::post('gAlbum/filter/', 'GAlbumController@filter');
    Route::resource('gallery', 'GalleryController');


    //Footer
    Route::get('footer', 'FooterController@index');

    Route::resource('contact-info', 'ContactInfoController');
    Route::resource('ourService', 'OurServiceController');
    Route::resource('support', 'SupportController');
    Route::resource('downloads', 'DownloadController');
    Route::resource('follow-us', 'FollowUsController');
    
    Route::post('userSubcription', 'SubcriptionController@subcription');
    
  
    Route::resource('majorCategories', 'MajorCategoriesController');
    
    //product category
    Route::post('productCategory/filter/', 'ProductCategoryController@filter');
    Route::get('productCategory', 'ProductCategoryController@index')->name('productCategory.index');
    Route::get('productCategory/create', 'ProductCategoryController@create')->name('productCategory.create');
    Route::post('productCategory', 'ProductCategoryController@store')->name('productCategory.store');
    Route::get('productCategory/{id}/edit', 'ProductCategoryController@edit')->name('productCategory.edit');
    Route::patch('productCategory/{id}', 'ProductCategoryController@update')->name('productCategory.update');
    Route::delete('productCategory/{id}', 'ProductCategoryController@destroy')->name('productCategory.destroy');
    
    
      //product
    Route::post('product/filter/', 'ProductController@filter');
    Route::get('product', 'ProductController@index')->name('product.index');
    Route::get('product/create', 'ProductController@create')->name('product.create');
    Route::post('product/loadProductNameCreate', 'ProductController@loadProductNameCreate');
    Route::post('product/store', 'ProductController@store')->name('product.store');
    Route::get('product/{id}/edit', 'ProductController@edit')->name('product.edit');
    Route::post('product/loadProductNameEdit', 'ProductController@loadProductNameEdit');
    Route::post('product/update', 'ProductController@update')->name('product.update');
    Route::delete('product/{id}', 'ProductController@destroy')->name('product.destroy');
    Route::post('product/getProductPricing', 'ProductController@getProductPricing');
    Route::post('product/setProductPricing', 'ProductController@setProductPricing');
    Route::post('product/showPricingHistory', 'ProductController@showPricingHistory');
    Route::post('product/getProductAttribute', 'ProductController@getProductAttribute');
    Route::post('product/setProductAttribute', 'ProductController@setProductAttribute');
    Route::post('product/getProductSKU', 'ProductController@getProductSKU');
    Route::post('product/setProductSKU', 'ProductController@setProductSKU');
    Route::post('product/getProductTag', 'ProductController@getProductTag');
    Route::post('product/setProductTag', 'ProductController@setProductTag');
    Route::post('product/trackProductPricingHistory', 'ProductController@trackProductPricingHistory');
    Route::post('product/brandDetails', 'ProductController@brandDetails');
    Route::post('product/getProductOffer', 'ProductController@getProductOffer');
    Route::post('product/setProductOffer', 'ProductController@setProductOffer');
    //set product image
    Route::get('product/{id}/getProductImage', 'ProductController@getProductImage');
    Route::post('product/setProductImage', 'ProductController@setProductImage');
    Route::post('product/newProductImage', 'ProductController@newProductImage')->name('product.newProductImage');
});
